#!/usr/bin/env python3
"""C안: 공칭 모델과 EFC 모델. 검토 단계는 3MF를 생성하지 않는다."""
from pathlib import Path
import sys,json,pickle
import numpy as np
import trimesh as tm
from shapely.geometry import Point,Polygon,LineString,box as rect
from shapely.ops import unary_union
from scipy.spatial import cKDTree
HERE=Path(__file__).resolve().parent; PROJ=HERE.parent; ROOT=PROJ.parent.parent
sys.path.insert(0,str(ROOT/'tools'))
from efc import pre_expand_first_layer
P=dict(OUTER_W=78.2,SIDE_R=100.,CORNER_R=30.,CAP_W=82.2,CAP_SIDE_R=102.,CAP_CORNER_R=32.,ID=69.8,BODY_L=243.,FLOOR=3.,CAP_T=10.,CLOSED_L=253.,TRAY_R=34.6,TRAY_T=2.6,TRAY_END=249.8,STOP_T=1.25,USE_L=225.,RADIAL_GAP=.3,GROOVE_D=.4,GROOVE_W=1.6,PATTERN_START=55.,PATTERN_END=190.,CONTENT_D=64.,CONTENT_L=225.,STACK_PITCH=28.,SHUTTLE_L=85.,CONTENT_BASE_D=28.,END_ANGLE_FROM_BED=45.,END_BRIDGE_D=4.,BODY_SPLIT_Z=121.5,GLUE_L=14.,GLUE_R=37.1,GLUE_INNER_R=34.9,GLUE_SOCKET_R=37.25,CONTENT_CLEARANCE=0.)
P.update(CAP_SQUARE_SIDE=30.,CAP_SQUARE_DEPTH=3.,CAP_KEY_SIDE=29.6,CAP_SNAP_L=22.6,CAP_SNAP_T=3.,CAP_SNAP_B=2.8,CAP_SNAP_DEFLECTION=.4)
P.update(GLUE_KEY_ANGLE=45.,GLUE_KEY_WIDTH=8.,GLUE_KEY_R=37.9,GLUE_KEY_SIDE_GAP=.10,GLUE_RADIAL_GAP=.15)
P.update(TRAY_INNER_R=32.,CAP_JOINT_L=4.,CAP_JOINT_GAP=.20,DETENT_Z=20.,CONTENT_OFFSET_Y=0.)
P.update(DETENT_COUNT=6,DETENT_PITCH=36.,DETENT_RELAX_GAP=.20)
P.update(GLUE_L=22.,GLUE_TAPER_L=5.,COLLAR_CUT_Y=-17.,FOOT_BOTTOM_Y=-34.8,FOOT_SIDE_SLOPE=0.,FOOT_WALL=2.6,DETENT_INTERFERENCE=.20,CONTENT_OFFSET_Y=0.)
P.update(FOOT_HALF_BASE=8.,FOOT_TOP_Y=-32.8,FOOT_ROUND=.5,CAM_FACE_Y=-34.,REAR_START=222.,REAR_LAP=10.,REAR_MALE_R=31.8,REAR_INNER_R=29.2,SEAM_WAVE_A=.8)
P.update(CAM_NORMAL_R=1.8,CAM_TANGENT_R=.60,CAM_AXIAL_R=3.,CAM_FACE_Y=-34.,DETENT_RELAX_GAP=.20)
COLORS={'shell':'#33383e','drawer':'#bd6f53','shell_coupon':'#33383e','drawer_coupon':'#bd6f53'}
def box(x0,y0,z0,x1,y1,z1):
 m=tm.creation.box([x1-x0,y1-y0,z1-z0]);m.apply_translation([(x0+x1)/2,(y0+y1)/2,(z0+z1)/2]);return m
def extr(poly,h,z=0):
 if hasattr(poly,'geoms'):
  return tm.util.concatenate([extr(p,h,z) for p in poly.geoms if p.area>1e-5])
 m=tm.creation.extrude_polygon(poly,h,engine='earcut');m.apply_translation([0,0,z]);return m
def cyl(r,h,z=0):
 m=tm.creation.cylinder(r,h,sections=192);m.apply_translation([0,0,z+h/2]);return m
def union(*ms):return tm.boolean.union(list(ms),engine='manifold')
def diff(a,*ms):return tm.boolean.difference([a,*ms],engine='manifold')
def semicircle(ro,ri):return Point(0,0).buffer(ro,quad_segs=48).difference(Point(0,0).buffer(ri,quad_segs=48)).intersection(rect(-ro-1,-ro-1,ro+1,0))
def wave_centerlines(bounds,pitch=24.,step=10.5):
 """四重の扇を上の扇で隠す。同じ単純半円を重ねて交差させない青海波。"""
 x0,y0,x1,y1=bounds;clip=rect(x0,y0,x1,y1);cover=Polygon();visible=[]
 rmax=pitch/2
 rows=range(int(np.floor(y0/step))-2,int(np.ceil(y1/step))+2)
 for row in reversed(list(rows)):
  cy=row*step;shift=pitch/2*(row%2);filled=[]
  for col in range(int(np.floor(x0/pitch))-2,int(np.ceil(x1/pitch))+2):
   cx=col*pitch+shift
   for r in (rmax*.23,rmax*.46,rmax*.69,rmax*.92):
    a=np.linspace(0,np.pi,61);line=LineString(np.c_[cx+r*np.cos(a),cy+r*np.sin(a)])
    g=line.difference(cover).intersection(clip)
    if not g.is_empty:visible.append(g)
   disk=Point(cx,cy).buffer(rmax,quad_segs=48).intersection(rect(cx-rmax-1,cy,cx+rmax+1,cy+rmax+1));filled.append(disk)
  cover=unary_union([cover,*filled])
 return unary_union(visible)
def wave_lines(clip):
 return wave_centerlines(clip.bounds).buffer(.6,cap_style='round',join_style='round').intersection(clip)
def double_curve(n=256,offset=0.,corner_radius=None):
 """Tangent R100 side / R30 corner arcs. Offset is an exact parallel curve.
 Four quadrants, sampled at uniform arc length; normals stay continuous at joins.
 """
 R=P['SIDE_R'];r=P['CORNER_R'] if corner_radius is None else float(corner_radius);d=R-P['OUTER_W']/2
 a=(-d+np.sqrt(2*(R-r)**2-d*d))/2
 alpha=np.arctan2(a,a+d);lengths=np.array([R*alpha,r*(np.pi/2-2*alpha),R*alpha]);L=sum(lengths)
 xy=[];normals=[]
 for s in np.arange(n)*(4*L/n):
  quadrant=int(s/L);u=s-quadrant*L
  if u<lengths[0]:t=u/R;c=np.array([-d,0]);radius=R
  elif u<sum(lengths[:2]):t=alpha+(u-lengths[0])/r;c=np.array([a,a]);radius=r
  else:t=np.pi/2-alpha+(u-sum(lengths[:2]))/R;c=np.array([0,-d]);radius=R
  normal=np.array([np.cos(t),np.sin(t)]);point=c+(radius+offset)*normal
  ang=quadrant*np.pi/2;rot=np.array([[np.cos(ang),-np.sin(ang)],[np.sin(ang),np.cos(ang)]])
  xy.append(rot@point);normals.append(rot@normal)
 return np.array(xy),np.array(normals),4*L
P['OUTER_PERIMETER']=float(double_curve()[2]);P['PATTERN_PITCH']=P['OUTER_PERIMETER']/10
def ring_solid(rings):
 n=len(rings[0]);vs=np.concatenate(rings).tolist();faces=[];nr=len(rings)
 for j in range(nr-1):
  for i in range(n):
   a=j*n+i;b=j*n+(i+1)%n;c=(j+1)*n+i;d=(j+1)*n+(i+1)%n;faces.extend([[a,b,c],[b,d,c]])
 bot=len(vs);vs.append([0,0,rings[0][0,2]]);top=len(vs);vs.append([0,0,rings[-1][0,2]])
 for i in range(n):faces.extend([[bot,(i+1)%n,i],[top,(nr-1)*n+i,(nr-1)*n+(i+1)%n]])
 m=tm.Trimesh(vs,faces,process=False);m.fix_normals();return m
def cap_solid():
 xy,normals,_=double_curve(256,2.);rings=[]
 for z in np.r_[np.linspace(0,4,17),6.,np.linspace(6,10,17)[1:]]:
  inset=1.3*(1+np.cos(np.pi*z/4))/2 if z<=4 else (.6*(1-np.cos(np.pi*(z-6)/4))/2 if z>6 else 0.)
  rings.append(np.c_[xy-inset*normals,np.full(len(xy),z)])
 return ring_solid(rings)
def high_resolution_outer(rings):
 """Dense surface identical in principle to approved R15 preview, sample-checked reduction."""
 import manifold3d as mf
 nr=len(rings);n=len(rings[0]);vertices=np.concatenate(rings).astype(np.float32)
 ids=np.arange((nr-1)*n,dtype=np.uint32).reshape(nr-1,n)
 a=ids.ravel();b=(np.roll(ids,-1,axis=1)).ravel();c=a+n;d=b+n
 faces=np.vstack([np.column_stack([a,b,c]),np.column_stack([b,d,c])])
 bot=len(vertices);top=bot+1
 vertices=np.vstack([vertices,[0,0,rings[0][0,2]],[0,0,rings[-1][0,2]]]).astype(np.float32)
 i=np.arange(n,dtype=np.uint32);j=(i+1)%n
 faces=np.vstack([faces,np.column_stack([np.full(n,bot),j,i]),np.column_stack([np.full(n,top),(nr-1)*n+i,(nr-1)*n+j])]).astype(np.uint32)
 solid=mf.Manifold(mf.Mesh(vert_properties=vertices,tri_verts=faces))
 raw_faces=len(faces)
 # QEM removes redundant dense-grid triangles while retaining sampled geometry accuracy.
 import fast_simplification
 reduced=solid.simplify(.006).to_mesh()
 reference=tm.Trimesh(vertices,faces,process=False)
 target_vertices,target_faces=fast_simplification.simplify(np.asarray(reduced.vert_properties)[:,:3].astype(np.float64),np.asarray(reduced.tri_verts).astype(np.int32),target_count=255000,agg=5)
 m=tm.Trimesh(target_vertices,target_faces,process=False)
 assert m.is_volume
 samples,_=tm.sample.sample_surface(reference,8000,seed=12)
 distances=[]
 for start in range(0,len(samples),500):
  _,distance,_=tm.proximity.closest_point(m,samples[start:start+500]);distances.extend(distance)
 maximum=float(np.max(distances));p99=float(np.percentile(distances,99))
 print('Dense ornament',raw_faces,'->',len(m.faces),'sample max',maximum,'p99',p99,flush=True)
 assert maximum<.05 and p99<.035,('ornament surface error',maximum,p99)
 count=len(m.faces);tol=.05
 P['PATTERN_SAMPLE_MAX_ERR_MM']=maximum;P['PATTERN_SAMPLE_P99_ERR_MM']=p99;P['PATTERN_SAMPLE_COUNT']=8000
 P['PATTERN_SAMPLING_CIRC_MM']=P['OUTER_PERIMETER']/1024
 P['PATTERN_SAMPLING_AXIAL_MM']=.12
 P['PATTERN_SIMPLIFY_TOL_MM']=tol
 P['PATTERN_PREVIEW_LAND_MM']=P['PATTERN_PITCH']*.5*.23-P['GROOVE_W']
 P['PATTERN_RAW_TRIANGLES']=raw_faces;P['PATTERN_REDUCED_OUTER_TRIANGLES']=count
 # Cap contact plane must stay exactly atBODY_L after exterior decimation.
 return tm.boolean.intersection([m,box(-50,-50,-1,50,50,P['BODY_L'])],engine='manifold')

def patterned_shell():
 n=1024;xy,normals,circ=double_curve(n);ss=np.arange(n)*circ/n;period=P['PATTERN_PITCH']
 lines=wave_centerlines((-period,40,circ+period,205),period,period*.525)
 from rail_geometry import joint_row
 cy,shift,rr=joint_row()
 connectors=[LineString([(i*period+shift+rr,cy),((i+1)*period+shift-rr,cy)]) for i in range(-2,13)]
 lines=unary_union([lines,*connectors])
 pts=[]
 def sample(g):
  if g.geom_type=='LineString':
   for d in np.linspace(0,g.length,max(2,int(g.length/.035)+1)):pts.append(g.interpolate(d).coords[0])
  elif hasattr(g,'geoms'):
   for q in g.geoms:sample(q)
 sample(lines);tree=cKDTree(np.array(pts))
 zs=np.unique(np.r_[np.linspace(0,6,16),53.,np.linspace(55.,190.,1126),np.linspace(P['BODY_SPLIT_Z']-2,P['BODY_SPLIT_Z']+2,65),192.,P['BODY_L']-2,np.linspace(P['BODY_L']-1.9,P['BODY_L'],8)])
 rings=[]
 for z in zs:
  dd=tree.query(np.c_[ss,np.full(n,z)])[0]
  dep=np.minimum(P['GROOVE_D']*np.clip(1-dd/(P['GROOVE_W']/2),0,1),max(0,.5*min(z-55,190-z)))
  inset=0.
  if z<6:inset=1.5*(1+np.cos(np.pi*z/6))/2
  if z>P['BODY_L']-2:inset=.6*(1-np.cos(np.pi*(z-P['BODY_L']+2)/2))/2
  rings.append(np.c_[xy-(inset+dep)[:,None]*normals,np.full(n,z)])
 m=high_resolution_outer(rings)
 m=diff(m,cyl(P['ID']/2,P['BODY_L'],3))
 return m
def roof_window(bottom,shoulder,half_width,x0,x1):
 top=shoulder+(half_width-2)/.55
 poly=Polygon([(-half_width,bottom),(half_width,bottom),(half_width,shoulder),(2,top),(-2,top),(-half_width,shoulder)])
 cut=extr(poly,x1-x0)
 cut.apply_transform(np.array([[0,0,1,x0],[1,0,0,0],[0,1,0,0],[0,0,0,1]],float))
 return cut
def cone_cavity_profile(end):
 """Full-width continuous circular profile:45deg at mouth to30deg at4mm roof.

 No straight cone run and no delayed tip-only blend. Angles are to print bed.
 """
 beta0=np.deg2rad(45.);beta1=np.deg2rad(60.)
 rt=P['TRAY_INNER_R'];rf=P['END_BRIDGE_D']/2
 R=(rt-rf)/(np.cos(beta0)-np.cos(beta1))
 roof=end-P['STOP_T'];start=roof-R*(np.sin(beta1)-np.sin(beta0))
 rc=rt-R*np.cos(beta0);zc=start-R*np.sin(beta0)
 points=[(rt,start-.1)]+[(rc+R*np.cos(t),zc+R*np.sin(t)) for t in np.linspace(beta0,beta1,193)]
 points[-1]=(rf,roof)
 P['END_BLEND_L']=roof-start;P['END_TIP_R']=R
 P['END_FINAL_BRIDGE_D']=2*rf;P['END_TERMINAL_ANGLE_FROM_BED']=30.
 P['END_ROUND_START_Z']=start;P['END_ROUND_START_D']=2*rt
 P['END_ACTUAL_ROOF_Z']=roof;P['END_ACTUAL_ROOF_T']=end-roof
 dr,dz=np.diff(np.array(points[-2:]),axis=0)[0]
 P['END_LAST_CHORD_ANGLE_FROM_BED']=float(np.rad2deg(np.arctan2(dz,-dr)))
 assert abs(P['END_LAST_CHORD_ANGLE_FROM_BED']-30)<.3
 return points

END_PROFILE=cone_cavity_profile(P['TRAY_END'])

def sphere(r,center):
 m=tm.creation.uv_sphere(radius=r,count=[16,24]);m.apply_translation(center);return m

def trough_profiles():
 from rail_geometry import foot_profile
 circle=Point(0,0).buffer(P['TRAY_R'],quad_segs=48).intersection(rect(-50,-50,50,0))
 outer=circle.union(foot_profile())
 inner=Point(0,0).buffer(P['TRAY_INNER_R'],quad_segs=48).intersection(rect(-50,-50,50,0))
 return outer,inner,outer.difference(inner)

def make_cap():
 outer,_,_=trough_profiles()
 cap_clip=Polygon(double_curve(256,-2.3)[0])
 cap=diff(cap_solid(),extr(wave_lines(cap_clip),.61,-.01))
 # Full half-disc socket4mm deep, then a30x30mm square pocket3mm deeper.
 cap=diff(cap,extr(outer.buffer(P['CAP_JOINT_GAP'],join_style='round'),4.02,6.),box(-15,-30,3.,15,0,6.02))
 catches=[]
 for sign in [-1,1]:
  xa,xb=sorted([sign*14.9,sign*15.55]);catches.append(box(xa,-7.7,3.5,xb,-4.8,5.1))
 return diff(cap,*catches)

def make_drawer(end=222.,end_stop=True,decorate=True):
 from revision_geometry import tray_main
 return tray_main(end,end_stop)


def pressed(mesh):
 # Kinematic detent-crossing proxy: trim nubs to the clearance channel.
 # This is not a material, force, or fatigue calculation.
 from rail_geometry import bore_profile
 return tm.boolean.intersection([mesh,extr(bore_profile(gap=.28),310,-5)],engine='manifold')

def cap_pressed(mesh):
 m=mesh.copy();v=m.vertices.copy()
 selected=(np.abs(v[:,0])>11.5)&(v[:,1]>=-27.6001)&(v[:,1]<=-4.9999)&(v[:,2]<6.0001)
 factor=np.clip((v[:,1]+27.6)/22.6,0,1)**2
 v[selected,0]-=np.sign(v[selected,0])*.4*factor[selected]
 m.vertices=v
 assert m.is_volume
 return m

def glue_key(clearance=False):
 z=P['BODY_SPLIT_Z'];end=z+P['GLUE_L'];g=P['GLUE_KEY_SIDE_GAP'] if clearance else 0.
 if clearance:
  from rail_geometry import joint_row
  z=joint_row()[0]-.2
 r=P['GLUE_KEY_R'];root=P['GLUE_R']-.2
 # Axial key with a1mm lead-in. One45-degree location gives unique orientation.
 poly=Polygon([(root,z-.01),(r+.15,z-.01),(r+.15,end-1),(r-.35,end+.2),(root,end+.2)]) if clearance else Polygon([(root,z-.01),(P['GLUE_R'],z-.01),(r,z+1.99),(r,end-1),(r-.5,end),(root,end)])
 m=extr(poly,P['GLUE_KEY_WIDTH']+2*g)
 m.apply_transform(np.array([[1,0,0,0],[0,0,1,-P['GLUE_KEY_WIDTH']/2-g],[0,1,0,0],[0,0,0,1]],float))
 m.apply_transform(tm.transformations.rotation_matrix(np.deg2rad(P['GLUE_KEY_ANGLE']),[0,0,1]))
 return m

def split_body(shell):
 from rail_geometry import remake_body_pair
 return remake_body_pair(shell)

def make_parts():
 from rail_geometry import make_shell_coupon
 from revision_geometry import rear_head
 cache=PROJ/'figures/patterned_parent_interlock.pkl'
 if cache.exists():parent=pickle.load(open(cache,'rb'))
 else:
  parent=patterned_shell();pickle.dump(parent.copy(include_cache=False),open(cache,'wb'))
 lower,upper=split_body(parent)
 return {'shell_lower':lower,'shell_upper':upper,'drawer':make_drawer(),'cap':make_cap(),'shell_coupon':make_shell_coupon(),'drawer_coupon':make_drawer(42.,False,False),'rear_head':rear_head()}

def print_transform(name,mesh):
 from trimesh.transformations import rotation_matrix as R
 if name in ['drawer','drawer_coupon']:M=R(np.pi/4,[0,0,1])@R(np.pi/2,[1,0,0])
 elif name in ['shell_upper','rear_head']:M=R(np.pi,[1,0,0])
 else:M=np.eye(4)
 copy=mesh.copy();copy.apply_transform(M);M[2,3]-=copy.bounds[0,2]
 return M

def main():
 from revision_geometry import finalize
 finalize(make_parts())
if __name__=='__main__':main()
