# Shuttle6 C R13 / ID64 / internal flat guide / six paired shallow detents — 파이프라인 보고

## 1. QC — 출력 방향 파트 (EFC 0.15 반영, 출력물 기준)

| 파트 | 삼각형 | 닫힘 | 조각 | 크기 (mm) | PLA g(통짜) | 바닥 접지 / 첫 층 mm² | 얇은 살 mm² | 오버행(한쪽) mm² | 브리지 mm² (최대 폭) | 판정 |
|---|---|---|---|---|---|---|---|---|---|---|
| shell_lower | 153,572 | O | 1 | 78.2×78.2×135.5 | 233.0 | 4866.3 / 4866.3 | 5.2 | 0.0 | 0.0 (0.0) | ℹ 얇은 살 허용: 키 선단1mm 삽입 유도면의 국부 모서리: 실제 QC5.2mm²,z135.2. 독립 벽/탄성 암이 아니며 뒤쪽 연속 collar 벽은 선단에서도1.85mm 이상, 축부2.20mm·키 폭8mm·길이14mm. 어깨부/키 뿌리는 깎지 않았고 선단의 작은 형상만 허용. 실제 강도 미검증. |
| shell_upper | 128,500 | O | 1 | 78.5×78.5×121.5 | 200.1 | 916.0 / 916.0 | 0.0 | 0.0 | 75.9 (4.9) | ✓ |
| drawer | 42,810 | O | 1 | 221.18×221.18×32.6 | 121.0 | 5746.2 / 5858.0 | 0.0 | 4652.0 | 0.8 (3.3) | ℹ 서포트: 내관 아래 곡면·돌기 부근: 실제 누적4652.0mm². 트리서포트. |
| cap | 109,904 | O | 1 | 82.2×82.2×10.0 | 55.9 | 4083.8 / 4083.8 | 0.0 | 0.0 | 1459.5 (1.9) | ✓ |
| shell_coupon | 3,652 | O | 1 | 78.5×78.5×36.0 | 63.1 | 1484.5 / 1484.5 | 0.0 | 0.0 | 0.0 (0.0) | ✓ |
| drawer_coupon | 1,080 | O | 1 | 74.25×74.25×32.6 | 22.1 | 850.7 / 867.1 | 0.0 | 754.8 | 0.8 (3.3) | ℹ 서포트: 눕힌 시험편 바닥 양옆 곡면과 돌기 아래. 트리 서포트. |
| tip_coupon | 16,460 | O | 1 | 55.86×55.86×32.6 | 20.9 | 238.1 / 242.6 | 0.0 | 180.0 | 0.0 (0.0) | ℹ 서포트: 눕힌 콘끝 시험편 바닥 양옆 전이부. 실제 QC 누적180.0mm². |

오버행 상위 위치: drawer: z=0.31 222.6 mm² [-4.4, -185.4, 185.4, 4.4]; z=2.91 191.9 mm² [-8.2, -189.2, 189.2, 8.2]; z=0.51 190.6 mm² [-4.8, -185.8, 185.8, 4.8]; z=0.71 181.8 mm² [-5.1, -186.1, 186.1, 5.1] / drawer_coupon: z=2.91 101.1 mm² [-8.2, -42.3, 42.3, 8.2]; z=0.31 32.7 mm² [-4.4, -38.5, 38.5, 4.4]; z=0.51 28.0 mm² [-4.8, -38.8, 38.8, 4.8]; z=0.71 26.7 mm² [-5.1, -39.2, 39.2, 5.1] / tip_coupon: z=0.31 9.0 mm² [-8.8, -15.7, 15.7, 8.8]; z=0.51 7.7 mm² [-9.1, -16.1, 16.1, 9.1]; z=0.71 7.3 mm² [-9.5, -16.4, 16.4, 9.5]; z=0.91 6.8 mm² [-9.8, -16.7, 16.7, 9.8]

브리지 상위 위치(z, mm², 폭): shell_upper: z=14.31 8.4 mm² 폭 4.9; z=14.51 4.5 mm² 폭 1.8; z=14.71 4.5 mm² 폭 2.6; z=14.91 4.4 mm² 폭 2.6 / drawer: z=25.11 0.8 mm² 폭 3.3 / cap: z=0.71 1457.1 mm² 폭 1.6; z=5.11 2.3 mm² 폭 1.9 / drawer_coupon: z=25.11 0.8 mm² 폭 3.3

얇은 살 위치: shell_lower: 5.2 mm² z=135.2 [23.3, 23.3, 29.4, 29.4]

## 2. 플레이트 3MF — 충돌·베드·lib3mf strict

| 플레이트 | 파트 | 범위 x / y (mm) | 충돌 | strict 경고 | 판정 |
|---|---|---|---|---|---|
| P01_body_pair.3mf | shell_lower, shell_upper | 33~223 / 89~167 | 0 | 0 | ✓ |
| P02_horizontal_tray.3mf | drawer | 17~239 / 17~239 | 0 | 0 | ✓ |
| P03_separate_cap.3mf | cap | 87~169 / 87~169 | 0 | 0 | ✓ |
| P04_detent_shell_coupon.3mf | shell_coupon | 89~167 / 89~167 | 0 | 0 | ✓ |
| P05_detent_tray_coupon.3mf | drawer_coupon | 91~165 / 91~165 | 0 | 0 | ✓ |
| P06_tip_coupon.3mf | tip_coupon | 100~156 / 100~156 | 0 | 0 | ✓ |

## 3. 조립 검증 — 상태별 교집합·간격 (표면 샘플 거리: 최소 / 1 % / 5 %)

| 상태 | A | B | 교집합 mm³ | 최소 / 1 % / 5 % mm | 판정 |
|---|---|---|---|---|---|
| 닫힘 | shell | drawer | 0.00 | 0.20 / 0.20 / 0.30 | 접촉(의도) |
| 닫힘 | shell | cap | 0.00 | 0.00 / 0.00 / 0.00 | 접촉(의도) |
| 닫힘 | drawer | cap | 0.00 | 0.10 / 0.20 / 0.20 | 접촉(의도) |
| 열림 | shell | drawer | 0.00 | 0.30 / 0.67 / 11.36 | 접촉(의도) |
| 열림 | shell | cap | 0.00 | 236.00 / 236.00 / 236.00 | 접촉(의도) |
| 열림 | drawer | cap | 0.00 | 0.10 / 0.20 / 0.20 | 접촉(의도) |
| 분리 | shell | drawer | 0.00 | 16.42 / 24.59 / 40.02 | 접촉(의도) |
| 분리 | shell | cap | 0.00 | 256.25 / 256.49 / 257.79 | 접촉(의도) |
| 분리 | drawer | cap | 0.00 | 13.22 / 14.35 / 16.32 | 접촉(의도) |
| 인출 36mm | shell | drawer | 0.00 | 0.20 / 0.30 / 0.30 | 접촉(의도) |
| 인출 36mm | shell | cap | 0.00 | 36.00 / 36.00 / 36.02 | 접촉(의도) |
| 인출 36mm | drawer | cap | 0.00 | 0.10 / 0.20 / 0.20 | 접촉(의도) |
| 인출 72mm | shell | drawer | 0.00 | 0.20 / 0.30 / 0.30 | 접촉(의도) |
| 인출 72mm | shell | cap | 0.00 | 72.00 / 72.00 / 72.01 | 접촉(의도) |
| 인출 72mm | drawer | cap | 0.00 | 0.13 / 0.20 / 0.20 | 접촉(의도) |
| 인출 108mm | shell | drawer | 0.00 | 0.20 / 0.30 / 0.30 | 접촉(의도) |
| 인출 108mm | shell | cap | 0.00 | 108.00 / 108.00 / 108.01 | 접촉(의도) |
| 인출 108mm | drawer | cap | 0.00 | 0.10 / 0.20 / 0.20 | 접촉(의도) |
| 인출 144mm | shell | drawer | 0.00 | 0.20 / 0.30 / 0.30 | 접촉(의도) |
| 인출 144mm | shell | cap | 0.00 | 144.00 / 144.00 / 144.00 | 접촉(의도) |
| 인출 144mm | drawer | cap | 0.00 | 0.10 / 0.20 / 0.20 | 접촉(의도) |
| 인출 180mm | shell | drawer | 0.00 | 0.20 / 0.30 / 2.90 | 접촉(의도) |
| 인출 180mm | shell | cap | 0.00 | 180.00 / 180.00 / 180.00 | 접촉(의도) |
| 인출 180mm | drawer | cap | 0.00 | 0.12 / 0.20 / 0.20 | 접촉(의도) |
| 몸통 접착 | shell_lower | shell_upper | 0.00 | 0.00 / 0.00 / 0.20 | 접촉(의도) |
| 뚜껑 끼움 전 | drawer | cap | 0.00 | 8.24 / 9.76 / 11.58 | 접촉(의도) |
| 뚜껑 딸깍 통과 | drawer_cap_pressed | cap | 0.00 | 0.02 / 0.20 / 1.14 | 접촉(의도) |
| 뚜껑 끼움 완료 | drawer | cap | 0.00 | 0.16 / 0.20 / 0.20 | 접촉(의도) |
| 딸깍 통과 18mm | shell | drawer_compressed | 0.00 | 0.05 / 0.30 / 0.30 | 접촉(의도) |
| 딸깍 통과 18mm | shell | cap | 0.00 | 18.00 / 18.00 / 18.04 | 접촉(의도) |
| 딸깍 통과 18mm | drawer_compressed | cap | 0.00 | 0.10 / 0.20 / 0.20 | 접촉(의도) |
| 딸깍 시험편 닫힘 | shell_coupon | drawer_coupon | 0.00 | 0.20 / 0.30 / 0.30 | 접촉(의도) |
| 딸깍 시험편 통과 | shell_coupon | coupon_compressed | 0.00 | 0.05 / 0.30 / 0.30 | 접촉(의도) |

- R13: Open nominal ID64, flat lower plane and2.6mm floor. Feather compliance is not modelled as rigid plastic.
- Tray prints horizontally on diagonal; cap separately face down. Body only2pieces upright.
- Long clip and release button removed; six pairs of low broad solid beads meet matching inner-shell pockets. Pull-through feel only, no rated positive lock.
- Bead crossing poses use a geometrically compressed bead for collision checks; this is a kinematic representation, not FEA or force validation.
- Actual dimensional/closed joint overlaps: {'drawer_vs_dimensional_gauge_mm3': 0.0, 'shell_vs_dimensional_gauge_mm3': 0.0, 'cap_joint_overlap_mm3': 0.0, 'rail_and_detents': {'flat_measurements': {'shell_flat_y_mm': -32.900001525878906, 'tray_outer_y_mm': -32.599998474121094, 'normal_gap_mm': 0.3000030517578125}, 'aligned_stage_checks': [{'extraction_mm': 0, 'overlap_mm3': 0.0, 'remaining_rows': 6}, {'extraction_mm': 36, 'overlap_mm3': 0.0, 'remaining_rows': 5}, {'extraction_mm': 72, 'overlap_mm3': 0.0, 'remaining_rows': 4}, {'extraction_mm': 108, 'overlap_mm3': 0.0, 'remaining_rows': 3}, {'extraction_mm': 144, 'overlap_mm3': 0.0, 'remaining_rows': 2}, {'extraction_mm': 180, 'overlap_mm3': 0.0, 'remaining_rows': 1}, {'extraction_mm': 216, 'overlap_mm3': 0.0, 'remaining_rows': 0}, {'extraction_mm': 236, 'overlap_mm3': 0.0, 'remaining_rows': 0}], 'rotation_samples_deg': [{'angle_deg': 0, 'overlap_mm3': 0.0}, {'angle_deg': -1, 'overlap_mm3': 0.0}, {'angle_deg': 1, 'overlap_mm3': 0.0}, {'angle_deg': -2, 'overlap_mm3': 26.20573715328178}, {'angle_deg': 2, 'overlap_mm3': 26.206001870678026}, {'angle_deg': -3, 'overlap_mm3': 177.73251028858715}, {'angle_deg': 3, 'overlap_mm3': 177.73226899874828}, {'angle_deg': -5, 'overlap_mm3': 597.5978227442852}, {'angle_deg': 5, 'overlap_mm3': 597.5978995669507}, {'angle_deg': -15, 'overlap_mm3': 2871.2515761934887}, {'angle_deg': 15, 'overlap_mm3': 2871.2510171936174}, {'angle_deg': 90, 'overlap_mm3': 2851.7346700534986}, {'angle_deg': 180, 'overlap_mm3': 0.0}], 'pocket_ray_measurements': [{'body_z_mm': 53, 'pocket_x_extent_mm': 34.84005355834961}, {'body_z_mm': 89, 'pocket_x_extent_mm': 34.84005355834961}, {'body_z_mm': 125, 'pocket_x_extent_mm': 34.84005355834961}, {'body_z_mm': 161, 'pocket_x_extent_mm': 34.84005355834961}, {'body_z_mm': 197, 'pocket_x_extent_mm': 34.84005355834961}, {'body_z_mm': 233, 'pocket_x_extent_mm': 34.84005355834961}], 'minimum_collar_wall_radial_bound_mm': 1.8500000000000014, 'scope': 'Rigid intersections and sample rotation obstruction only. Samples block continuous rotation from2deg. An open half-tray may be separately inserted upside-down at180deg; this is not unique orientation coding. Compressed nubs are kinematic proxies; no wall elasticity, click force, wear, torque rating or fatigue simulation.'}, 'cap_joint_measured': {'pocket_depth_mm': 4.0, 'tongue_length_mm': 3.8, 'gap_per_side_mm': 0.2, 'floor_gap_mm': 0.2, 'primary_pocket_floor_z_mm': 6.0, 'minimum_front_wall_mm': 3.0, 'square_pocket_side_mm': 30.0, 'square_pocket_depth_mm': 3.0, 'square_key_side_mm': 29.6, 'square_key_length_mm': 3.0, 'mode': 'Full half-disc socket plus30mm square pocket and protected snap beams. Physical cap retention is not rated.', 'actual_solid_overlap_mm3': 0.0, 'measured_pocket_depth_mm': 4.0, 'measured_solid_tongue_length_mm': 3.8000001907348633, 'measured_floor_gap_mm': 0.19999980926513672, 'measured_square_pocket_depth_mm': 3.0, 'measured_square_pocket_side_mm': 30.0}, 'cap_deflected_insertion_checks': [{'cap_offset_mm': -1.5, 'compressed_overlap_mm3': 0.0}, {'cap_offset_mm': -1.0, 'compressed_overlap_mm3': 0.0}, {'cap_offset_mm': -0.5, 'compressed_overlap_mm3': 0.0}], 'cap_joint_insertion_checks': [{'cap_offset_mm': -6, 'solid_overlap_mm3': 0.0}, {'cap_offset_mm': -4, 'solid_overlap_mm3': 0.0}, {'cap_offset_mm': -2, 'solid_overlap_mm3': 0.11250059008659719}, {'cap_offset_mm': -1, 'solid_overlap_mm3': 1.3000007390974133}, {'cap_offset_mm': 0, 'solid_overlap_mm3': 0.0}], 'detent_crossing_without_compliance': [{'extraction_mm': 0, 'rigid_overlap_mm3': 0.0}, {'extraction_mm': 0.5, 'rigid_overlap_mm3': 0.00015033171137342669}, {'extraction_mm': 2, 'rigid_overlap_mm3': 2.129960368344352}, {'extraction_mm': 10, 'rigid_overlap_mm3': 1.9806027706897567}, {'extraction_mm': 18, 'rigid_overlap_mm3': 1.8306935203446906}, {'extraction_mm': 34, 'rigid_overlap_mm3': 1.7749652145990162}, {'extraction_mm': 36, 'rigid_overlap_mm3': 0.0}, {'extraction_mm': 54, 'rigid_overlap_mm3': 1.4645551357745983}, {'extraction_mm': 72, 'rigid_overlap_mm3': 0.0}, {'extraction_mm': 90, 'rigid_overlap_mm3': 1.0984163332952903}, {'extraction_mm': 108, 'rigid_overlap_mm3': 0.0}, {'extraction_mm': 126, 'rigid_overlap_mm3': 0.7322765621682947}, {'extraction_mm': 144, 'rigid_overlap_mm3': 0.0}, {'extraction_mm': 162, 'rigid_overlap_mm3': 0.3661380113319031}, {'extraction_mm': 180, 'rigid_overlap_mm3': 0.0}, {'extraction_mm': 190, 'rigid_overlap_mm3': 0.18306989244568891}, {'extraction_mm': 216, 'rigid_overlap_mm3': 0.0}, {'extraction_mm': 236, 'rigid_overlap_mm3': 0.0}], 'glue_key_rotation_checks': [{'angle_deg': 0, 'solid_overlap_mm3': 0.0}, {'angle_deg': -0.5, 'solid_overlap_mm3': 2.669155618912763}, {'angle_deg': 0.5, 'solid_overlap_mm3': 2.6691569272463007}, {'angle_deg': -1, 'solid_overlap_mm3': 6.383907867075474}, {'angle_deg': 1, 'solid_overlap_mm3': 6.383907452804654}, {'angle_deg': -3, 'solid_overlap_mm3': 19.98008273016357}, {'angle_deg': 3, 'solid_overlap_mm3': 19.980082377780793}, {'angle_deg': 90, 'solid_overlap_mm3': 79.19498414670063}], 'glue_joint_measured': {'collar_wall_mm': 2.2000007547093503, 'radial_gap_mm': 0.14999962232591457, 'key_tip_gap_mm': 0.14999962232591457, 'key_side_gap_mm': 0.10000082734596782, 'key_width_mm': 7.999998918996401}, 'glue_joint_axial_insertion_checks': [{'remaining_insertion_mm': 0, 'overlap_mm3': 0.0}, {'remaining_insertion_mm': 2, 'overlap_mm3': 0.0}, {'remaining_insertion_mm': 5, 'overlap_mm3': 0.0}, {'remaining_insertion_mm': 10, 'overlap_mm3': 0.0}, {'remaining_insertion_mm': 14, 'overlap_mm3': 0.0}, {'remaining_insertion_mm': 16, 'overlap_mm3': 0.0}], 'scope': 'Nominal64mm dimensional gauge offset upward2mm over flat floor,6 nested225mm assumption. Not a measured feather envelope or deformation/contact simulation. Six paired broad beads have intentional elastic crossing; trough-wall compliance is not simulated and click force is not calculated.'}.
- Cap has4mm full half-disc socket plus30x30x3mm square pocket; solid boat nose has protected spring hooks. Nominal closed overlap and deflected passage are checked; no rated real retention strength.
- Full extraction, dimensional gauge and coupon states were verified against the identical meshes in the preceding review_R13. Print-project overview retains seven assembly/cap states; scalar dimensional/interference/rotation/spring checks still run in full_define.

## 4. 렌더 (CPU flat-shaded mesh, 5뷰 + 회전 GIF + 작동 GIF)

- 플레이트 `P01_body_pair.3mf`: `qc/final_R13/plate_P01_body_pair/view_*.png`, `turntable.gif`
- 플레이트 `P02_horizontal_tray.3mf`: `qc/final_R13/plate_P02_horizontal_tray/view_*.png`, `turntable.gif`
- 플레이트 `P03_separate_cap.3mf`: `qc/final_R13/plate_P03_separate_cap/view_*.png`, `turntable.gif`
- 플레이트 `P04_detent_shell_coupon.3mf`: `qc/final_R13/plate_P04_detent_shell_coupon/view_*.png`, `turntable.gif`
- 플레이트 `P05_detent_tray_coupon.3mf`: `qc/final_R13/plate_P05_detent_tray_coupon/view_*.png`, `turntable.gif`
- 플레이트 `P06_tip_coupon.3mf`: `qc/final_R13/plate_P06_tip_coupon/view_*.png`, `turntable.gif`
- 조립 상태(분리/닫힘/열림…): `qc/final_R13/assembly/view_*_<상태>.png`, `turntable.gif`

## 5. 판정

- ℹ shell_lower: 1.2 mm 보다 얇은 살 5.2 mm² (z=135.2, x/y (23.3, 23.3, 29.4, 29.4)) → 허용(키 선단1mm 삽입 유도면의 국부 모서리: 실제 QC5.2mm²,z135.2. 독립 벽/탄성 암이 아니며 뒤쪽 연속 collar 벽은 선단에서도1.85mm 이상, 축부2.20mm·키 폭8mm·길이14mm. 어깨부/키 뿌리는 깎지 않았고 선단의 작은 형상만 허용. 실제 강도 미검증.)
- ℹ drawer: 오버행 4652.0 mm² → 서포트(내관 아래 곡면·돌기 부근: 실제 누적4652.0mm². 트리서포트., 허용 4700)
- ℹ drawer_coupon: 오버행 754.8 mm² → 서포트(눕힌 시험편 바닥 양옆 곡면과 돌기 아래. 트리 서포트., 허용 780)
- ℹ tip_coupon: 오버행 180.0 mm² → 서포트(눕힌 콘끝 시험편 바닥 양옆 전이부. 실제 QC 누적180.0mm²., 허용 190)
- ✓ 경고 없음 — 보낼 수 있음
