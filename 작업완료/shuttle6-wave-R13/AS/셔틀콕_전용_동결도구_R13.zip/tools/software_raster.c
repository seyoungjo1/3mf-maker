/* Exact per-pixel depth for the offline CAD mesh renderer. */
#include <math.h>
#include <stdint.h>
void mm_raster(int w,int h,int count,const float *t,const uint8_t *col,uint8_t *img,float *depth){
 for(int k=0;k<count;k++){
  const float *v=t+9*k;
  float den=(v[4]-v[7])*(v[0]-v[6])+(v[6]-v[3])*(v[1]-v[7]);
  if(fabsf(den)<1e-8f)continue;
  int x0=(int)floorf(fminf(v[0],fminf(v[3],v[6]))),x1=(int)ceilf(fmaxf(v[0],fmaxf(v[3],v[6])));
  int y0=(int)floorf(fminf(v[1],fminf(v[4],v[7]))),y1=(int)ceilf(fmaxf(v[1],fmaxf(v[4],v[7])));
  if(x0<0)x0=0;if(y0<0)y0=0;if(x1>w-1)x1=w-1;if(y1>h-1)y1=h-1;
  for(int y=y0;y<=y1;y++)for(int x=x0;x<=x1;x++){
   float px=x+.5f,py=y+.5f;
   float a=((v[4]-v[7])*(px-v[6])+(v[6]-v[3])*(py-v[7]))/den;
   float b=((v[7]-v[1])*(px-v[6])+(v[0]-v[6])*(py-v[7]))/den;
   float c=1-a-b;
   if(a<-.00001f||b<-.00001f||c<-.00001f)continue;
   float z=a*v[2]+b*v[5]+c*v[8];int p=y*w+x;
   if(z>depth[p]){depth[p]=z;img[3*p]=col[3*k];img[3*p+1]=col[3*k+1];img[3*p+2]=col[3*k+2];}
  }
 }
}
