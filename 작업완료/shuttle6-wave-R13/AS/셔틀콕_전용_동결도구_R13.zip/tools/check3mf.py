#!/usr/bin/env python3
"""lib3mf strict 모드로 3MF 를 읽어 경고 수를 센다. 사용: python tools/check3mf.py a.3mf [b.3mf ...]  (경로는 ASCII 권장)"""
import sys, lib3mf

# 3MF Core model metadata names. Bambu additionally stores vendor metadata
# (e.g. BambuStudio:3mfVersion), which lib3mf rejects in strict mode.
CORE_METADATA = {'Title','Designer','Description','Copyright','LicenseTerms','Rating','CreationDate','ModificationDate','Application'}

def check_bambu_geometry(path, template=None):
    """Preserve the delivered Bambu file; strict-check a geometry-only copy.

    Only vendor metadata and attributes found in the real user-exported
    template are accepted. Unknown metadata or attributes fail. The copy
    encodes the decoded original meshes and transforms as standard 3MF Core.
    Project settings and Bambu metadata are independently verified on the
    original file, and raw strict failure is reported explicitly.
    """
    import os,tempfile,zipfile,json,xml.etree.ElementTree as ET
    import bambu_project as BP
    from generic3mf import write_generic_3mf
    template=template or BP.DEFAULT_TEMPLATE
    project=BP.verify_bambu_project(path,template)
    if not project['ok']:raise ValueError(f'Bambu project structure: {project["errors"]}')
    original_error=None
    try: raw_n,raw_messages,_=check(path)
    except Exception as e:
        if not any(s in str(e) for s in ['Unknown Model Metadata','Invalid Attribute in namespace']):raise
        original_error=str(e);raw_n=None;raw_messages=[]
    if raw_n:raise ValueError(f'Original strict warnings: {raw_messages}')
    ns='{http://schemas.microsoft.com/3dmanufacturing/core/2015/02}'
    known=set();known_attributes=set()
    with zipfile.ZipFile(template) as z:
        for name in z.namelist():
            if name.endswith('.model'):
                root=ET.fromstring(z.read(name))
                known.update(m.get('name') for m in root.findall(ns+'metadata'))
                known_attributes.update((e.tag,k) for e in root.iter() for k in e.attrib)
    removed=set()
    with tempfile.TemporaryDirectory(prefix='bambu_geometry_') as directory:
        copy=os.path.join(directory,'geometry.3mf')
        with zipfile.ZipFile(path) as source:
            for item in source.infolist():
                data=source.read(item.filename)
                if item.filename.endswith('.model'):
                    root=ET.fromstring(data)
                    for e in root.iter():
                        for key in e.attrib:
                            if (e.tag,key) not in known_attributes:raise ValueError(f'Unknown non-template model attribute: {e.tag}:{key}')
                    for md in root.findall(ns+'metadata'):
                        key=md.get('name')
                        if key in CORE_METADATA:continue
                        if key not in known:raise ValueError(f'Unknown non-template metadata: {key}')
                        removed.add(key)
            colors=json.loads(source.read('Metadata/project_settings.config'))['filament_colour']
        # lib3mf also rejects some template production attributes in strict mode.
        # Decode the actual original components/transforms, then encode exactly
        # those world-space meshes as 3MF Core for the strict geometry check.
        core=[]
        for ob in BP.read_plate(path):
            core.append({'name':ob['name'],'parts':[(m,colors[e-1],n) for m,n,e in ob['parts']]})
        write_generic_3mf(copy,core,title='Geometry validation copy')
        n,messages,objects=check(copy)
    return {'warnings':n,'messages':messages[:5],'objects':objects,
            'mode':'Bambu original structure + geometry-copy strict',
            'original_strict_error':original_error,'removed_template_metadata':sorted(removed),
            'copy_encoding':'3MF Core with original world-space meshes and transforms',
            'bambu_structure_ok':project['ok']}

def check(path):
    w = lib3mf.get_wrapper(); model = w.CreateModel(); r = model.QueryReader('3mf'); r.SetStrictModeActive(True)
    r.ReadFromFile(path); n = r.GetWarningCount()
    warns = [r.GetWarning(i)[1] if isinstance(r.GetWarning(i), tuple) else str(r.GetWarning(i)) for i in range(n)]
    objs = model.GetObjects(); cnt = 0
    while objs.MoveNext(): cnt += 1
    return n, warns, cnt
if __name__ == '__main__':
    bad = 0
    for p in sys.argv[1:]:
        n, warns, cnt = check(p); bad += n
        print(f'{p}: strict 경고 {n}, 오브젝트 {cnt}' + (' | ' + '; '.join(warns[:5]) if warns else ''))
    sys.exit(1 if bad else 0)
