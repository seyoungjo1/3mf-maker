#!/usr/bin/env python3
"""3d-print 열쇠고리 프로그램의 미리보기(three.js, 어두운 배경, 격자 베드, flatShading)를 헤드리스로 재현해
PNG 5장(기본 iso/상부 top/측면 side/밑면 bottom/정면 저각도 front)과 회전 GIF 를 만든다.
사용: python tools/render_preview.py <file.3mf | a.stl b.stl ...> --out <dir> [--colors name=#hex,...] [--states states.json] [--frames 36]
  states.json: {"분리": {"lid": [0,0,30]}, "조립": {"lid": [16개 행우선 4x4 행렬]}}  (파트별 평행이동 [dx,dy,dz] 또는 4x4 행렬; 상태에 없는 파트는 그 상태에서 숨김)  → 상태별 PNG + GIF 에 상태 순환(키캡의 분리/조립-폄/조립-누름과 같은 방식)
"""
import os, sys, json, argparse, numpy as np
from pathlib import Path
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from load3mf import load_parts
import trimesh
def find_chrome():
    """Chromium 실행 파일 찾기: CHROME_PATH 환경변수 → 클라우드 기본(/opt/pw-browsers) → playwright 설치본 → 시스템 Chrome/Chromium/Edge.
    없으면 None (playwright 기본 브라우저 시도)."""
    import shutil, glob, platform
    cands = [os.environ.get('CHROME_PATH', ''), '/opt/pw-browsers/chromium']
    cands += sorted(glob.glob('/opt/pw-browsers/chromium-*/chrome-linux/chrome'), reverse=True)
    home = os.path.expanduser('~')
    for base in (os.environ.get('PLAYWRIGHT_BROWSERS_PATH', ''), os.path.join(home, '.cache', 'ms-playwright'),
                 os.path.join(home, 'AppData', 'Local', 'ms-playwright'), os.path.join(home, 'Library', 'Caches', 'ms-playwright')):
        # 실행 파일 이름을 정확히 지정한다('chrome*' 로 잡으면 chrome_sandbox·chrome_crashpad_handler 가 먼저 걸려 렌더가 죽는다 — CI 에서 실제로 발생)
        if base:
            for pat in (('chromium-*', '*', 'chrome'), ('chromium-*', '*', 'chrome.exe'), ('chromium_headless_shell-*', '*', 'chrome-headless-shell'),
                        ('chromium-*', '*', '*.app', 'Contents', 'MacOS', 'Chromium'), ('chromium-*', '*', '*.app', 'Contents', 'MacOS', 'Google Chrome for Testing')):
                cands += sorted(glob.glob(os.path.join(base, *pat)), reverse=True)
    for n in ('chromium', 'chromium-browser', 'google-chrome', 'google-chrome-stable', 'chrome', 'msedge'):
        w = shutil.which(n)
        if w: cands.append(w)
    cands += [r'C:\Program Files\Google\Chrome\Application\chrome.exe', r'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe',
              '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', '/Applications/Chromium.app/Contents/MacOS/Chromium']
    for c in cands:
        if c and os.path.isfile(c) and os.access(c, os.X_OK): return c
    return None
CHROME = find_chrome()
def check():
    """렌더러 점검: playwright·Chromium·three.js 뷰어 파일. 세션 시작 훅이 부른다."""
    ok = True
    try: import playwright  # noqa
    except ImportError: print('⚠ 렌더러: playwright 미설치 — pip install playwright (브라우저는 기존 Chrome/Chromium 사용)'); ok = False
    for f in ('three.module.js', 'OrbitControls.js'):
        if not os.path.isfile(os.path.join(HERE, 'viewer', f)): print(f'⚠ 렌더러: tools/viewer/{f} 없음'); ok = False
    print(f'렌더러: Chromium = {CHROME}' if CHROME else '⚠ 렌더러: Chromium 실행 파일을 못 찾음 — CHROME_PATH 환경변수로 지정하거나 python -m playwright install chromium')
    if ok and CHROME: print('렌더러: 준비됨 (python tools/render_preview.py <파일> --out <dir>)')
    return ok and CHROME is not None
PALETTE = ['#37474f', '#ffb300', '#78909c', '#7ccb8b', '#e57373', '#ba68c8', '#4dd0e1', '#a1887f']

HTML = r'''<!doctype html><html><head><meta charset="utf-8"><style>
html,body{margin:0;background:#1a1d21;overflow:hidden}#viewer{width:__W__px;height:__H__px}
#status{position:absolute;left:12px;bottom:10px;color:#c8cdd3;font:13px/1.5 sans-serif;white-space:pre;background:#1b1e23cc;border:1px solid #3c4043;border-radius:8px;padding:6px 10px}
#label{position:absolute;right:12px;top:10px;color:#e8eaed;font:13px sans-serif;background:#23272ecc;border:1px solid #3c4043;border-radius:6px;padding:5px 10px}
</style></head><body><div id="viewer"></div><div id="status"></div><div id="label"></div>
<script type="importmap">{"imports":{"three":"/viewer/three.module.js"}}</script>
<script type="module">
import * as THREE from 'three'; import { OrbitControls } from '/viewer/OrbitControls.js';
const DATA = await (await fetch('/data.json')).json();
const viewer=document.getElementById('viewer'); const scene=new THREE.Scene(); scene.background=new THREE.Color(0x1a1d21);
const camera=new THREE.PerspectiveCamera(45,__W__/__H__,0.1,4000); const renderer=new THREE.WebGLRenderer({antialias:true,preserveDrawingBuffer:true});
renderer.setSize(__W__,__H__); renderer.setPixelRatio(1); viewer.appendChild(renderer.domElement);
const controls=new OrbitControls(camera,renderer.domElement);
scene.add(new THREE.HemisphereLight(0xffffff,0x444455,1.1));
const dir=new THREE.DirectionalLight(0xffffff,1.2); dir.position.set(-40,-60,90); scene.add(dir);
const dirUp=new THREE.DirectionalLight(0xffffff,0.55); dirUp.position.set(40,60,-90); scene.add(dirUp);
const bedSize=DATA.bed||256; const grid=new THREE.GridHelper(bedSize,bedSize/10,0x3c4043,0x2a2e33); grid.rotation.x=Math.PI/2; grid.position.set(bedSize/2,bedSize/2,0); scene.add(grid);
const bedMat=new THREE.MeshStandardMaterial({color:0x23282e,roughness:0.85,metalness:0.1});
const bed=new THREE.Mesh(new THREE.BoxGeometry(bedSize,bedSize,2),bedMat); bed.position.set(bedSize/2,bedSize/2,-1.05); scene.add(bed);
const meshes={}; const box=new THREE.Box3();
for(const p of DATA.parts){ const g=new THREE.BufferGeometry(); g.setAttribute('position',new THREE.Float32BufferAttribute(p.positions,3)); g.setIndex(p.indices); g.computeVertexNormals();
  const m=new THREE.Mesh(g,new THREE.MeshStandardMaterial({color:p.color,roughness:0.55,metalness:0.05,flatShading:true})); m.userData.base=new THREE.Vector3(0,0,0); scene.add(m); meshes[p.name]=m; box.expandByObject(m); }
camera.up.set(0,0,1); let c=new THREE.Vector3(), s=100;
function fit(){ const bb=new THREE.Box3(); for(const m of Object.values(meshes)){ if(!m.visible) continue; m.updateMatrixWorld(true); bb.expandByObject(m); } if(bb.isEmpty()){ for(const m of Object.values(meshes)) bb.expandByObject(m); } c=bb.getCenter(new THREE.Vector3()); s=bb.getSize(new THREE.Vector3()).length(); }
window.setView=function(mode,azDeg){ fit(); controls.target.copy(c); grid.visible=mode!=='bottom'; bed.visible=mode!=='bottom';
  if(mode==='top') camera.position.set(c.x,c.y-s*0.001,c.z+s*1.3);
  else if(mode==='side') camera.position.set(c.x,c.y-s*1.3,c.z+s*0.03);
  else if(mode==='bottom') camera.position.set(c.x,c.y-s*0.001,c.z-s*1.3);
  else if(mode==='front') camera.position.set(c.x+s*0.25,c.y-s*1.15,c.z+s*0.22);
  else { const a=(azDeg===undefined?0:azDeg)*Math.PI/180; const r=s*0.9; camera.position.set(c.x+r*Math.sin(a),c.y-r*Math.cos(a),c.z+s*0.8); }
  camera.lookAt(c); controls.update(); renderer.render(scene,camera); };
window.setState=function(name){ const st=(DATA.states||{})[name]||{}; const any=Object.keys(st).length>0; for(const [n,m] of Object.entries(meshes)){ const d=st[n]; m.visible=!any||d!==undefined; m.matrixAutoUpdate=false; if(Array.isArray(d)&&d.length===16){ m.matrix.set(...d); } else { const t=d||[0,0,0]; m.matrix.makeTranslation(t[0],t[1],t[2]); } } const lb=document.getElementById('label'); lb.textContent=name||''; lb.style.display=name?'block':'none'; };
document.getElementById('status').textContent=DATA.status||'';
window.setState(DATA.firstState||''); window.setView('iso',0); window.READY=true;
</script></body></html>'''

def mesh_json(m, color, name):
    V = np.asarray(m.vertices, np.float32); F = np.asarray(m.faces, np.uint32)
    return {'name': name, 'color': color, 'positions': [round(float(v), 3) for v in V.ravel()], 'indices': [int(i) for i in F.ravel()]}

def offline_html(data, width, height):
    """Local modules and embedded data: rendering needs no HTTP listener or network grant."""
    viewer = (Path(HERE) / 'viewer').resolve().as_uri() + '/'
    payload = json.dumps(data).replace('<', '\\u003c')
    return (HTML.replace('__W__', str(width)).replace('__H__', str(height))
            .replace('/viewer/', viewer)
            .replace("await (await fetch('/data.json')).json()", payload))

def load(paths):
    parts = {}
    for p in paths:
        if p.lower().endswith('.3mf'):
            parts.update(load_parts(p))
        else: parts[os.path.splitext(os.path.basename(p))[0]] = trimesh.load(p, force='mesh')
    return parts

def render_software(parts, out, colors=None, states=None, frames=36, size=(1200,900), gif_size=(640,480), status=None, bed=256):
    """실제 메시의 CPU 평면 음영 렌더. 소켓 생성이 금지된 환경에서도 같은 5뷰/상태/GIF를 만든다."""
    from PIL import Image, ImageDraw, ImageFont
    from matplotlib.colors import to_rgb
    from trimesh.transformations import rotation_matrix
    import ctypes,hashlib,subprocess,tempfile
    src=Path(HERE)/'software_raster.c';digest=hashlib.sha256(src.read_bytes()).hexdigest()[:16]
    libpath=Path(tempfile.gettempdir())/('mm_raster_'+digest+'.so')
    if not libpath.exists():
        temp=str(libpath)+'.'+str(os.getpid())
        subprocess.run(['cc','-shared','-O3','-fPIC',str(src),'-o',temp,'-lm'],check=True,capture_output=True)
        os.replace(temp,libpath)
    lib=ctypes.CDLL(str(libpath));raster=lib.mm_raster
    ptr=np.ctypeslib.ndpointer
    raster.argtypes=[ctypes.c_int,ctypes.c_int,ctypes.c_int,ptr(np.float32,flags='C_CONTIGUOUS'),ptr(np.uint8,flags='C_CONTIGUOUS'),ptr(np.uint8,flags='C_CONTIGUOUS'),ptr(np.float32,flags='C_CONTIGUOUS')]
    os.makedirs(out,exist_ok=True); colors=colors or {}; pngs={}
    font_path='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
    font=ImageFont.truetype(font_path,16) if os.path.exists(font_path) else ImageFont.load_default()
    def placed(st):
        active=(states or {}).get(st,{})
        result=[]
        for i,(n,m) in enumerate(parts.items()):
            if active and n not in active:continue
            a=np.asarray(active.get(n,np.eye(4)),float)
            if a.shape==(3,): M=np.eye(4);M[:3,3]=a
            else:M=a.reshape(4,4)
            v=np.asarray(m.vertices)@M[:3,:3].T+M[:3,3]
            result.append((v,np.asarray(m.faces),np.asarray(to_rgb(colors.get(n,PALETTE[i%len(PALETTE)])))))
        return result
    def draw(st,mode,az,res):
        w,h=res; im=Image.new('RGB',res,'#1a1d21'); d=ImageDraw.Draw(im)
        scene=placed(st); vs=np.vstack([v for v,_,_ in scene]);lo=vs.min(0);hi=vs.max(0);c=(lo+hi)/2
        direction={'top':[.001,-.001,1],'bottom':[.001,-.001,-1],'side':[0,-1,.025],'front':[.25,-1,.2]}.get(mode,[np.sin(np.radians(az)),-np.cos(np.radians(az)),.75])
        front=np.asarray(direction,float);front/=np.linalg.norm(front);right=np.cross([0,0,1],front);right/=np.linalg.norm(right);up=np.cross(front,right)
        pr=np.c_[(vs-c)@right,(vs-c)@up]; span=np.maximum(np.ptp(pr,axis=0),1);sc=min((w-100)/span[0],(h-130)/span[1])
        def proj(v):return np.c_[w/2+(v-c)@right*sc,h/2-15-(v-c)@up*sc]
        if mode!='bottom':
            for q in range(0,bed+1,16):
                for v in (np.array([[q,0,0],[q,bed,0]]),np.array([[0,q,0],[bed,q,0]])):
                    pp=proj(v);d.line([tuple(pp[0]),tuple(pp[1])],fill='#30343b',width=1)
        polygons=[];shades=[];light=np.array([-.35,-.55,.76]);light/=np.linalg.norm(light)
        for v,f,rgb in scene:
            tri=v[f];norm=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);norm/=np.maximum(np.linalg.norm(norm,axis=1)[:,None],1e-12)
            visible=norm@front>0
            polys=proj(tri[visible].reshape(-1,3)).reshape(-1,3,2)
            zz=(tri[visible]-c)@front
            polygons.append(np.concatenate([polys,zz[:,:,None]],axis=2))
            # Match the bright hemisphere + key light used by the WebGL preview.
            sh=.7+.55*np.maximum(norm[visible]@light,0);shades.append(np.clip(rgb[None,:]*sh[:,None]*255,0,255).astype(np.uint8))
        tris=np.ascontiguousarray(np.concatenate(polygons),dtype=np.float32);cols=np.ascontiguousarray(np.concatenate(shades),dtype=np.uint8)
        pixels=np.array(im,dtype=np.uint8);zb=np.full((h,w),-1e30,np.float32)
        raster(w,h,len(tris),tris,cols,pixels,zb)
        # Screen-space cavity shading from actual depth; makes recessed geometry legible.
        from scipy.ndimage import grey_closing
        radius=max(1,min(10,int(sc*1.6)));closed=grey_closing(zb,size=(2*radius+1,2*radius+1))
        ao=np.clip((closed-zb-.04)/.5,0,1);ao[zb<-1e20]=0
        pixels=(pixels.astype(float)*(1-.48*ao[:,:,None])).astype(np.uint8)
        im=Image.fromarray(pixels);d=ImageDraw.Draw(im)
        if st:d.text((14,10),st,font=font,fill='#f0f0f0')
        label=status or ('검토 — '+' × '.join(f'{x:.1f}' for x in hi-lo)+' mm')
        d.rectangle([0,h-47,w,h],fill='#23272e');d.text((12,h-38),label+' · CPU mesh render',font=font,fill='#d5d9df')
        return im
    names=list(states) if states else ['']
    for st in names:
        for mode in ('iso','top','side','bottom','front'):
            fn='view_'+mode+('_'+st if st else '')+'.png';draw(st,mode,-35,size).save(os.path.join(out,fn));pngs[fn]=fn
    imgs=[];per=max(1,frames//len(names))
    for st in names:
        for k in range(per):imgs.append(draw(st,'iso',-35+360*k/per,gif_size).quantize(colors=128))
    imgs[0].save(os.path.join(out,'turntable.gif'),save_all=True,append_images=imgs[1:],duration=max(70,int(5000/len(imgs))),loop=0)
    json.dump({'backend':'software','states':names,'views':list(pngs),'frames':len(imgs)},open(os.path.join(out,'render_manifest.json'),'w'),ensure_ascii=False,indent=1)
    return pngs

def render(parts, out, colors=None, states=None, frames=36, size=(1200, 900), gif_size=(640, 480), status=None, bed=256):
    if os.environ.get('MM_RENDER_BACKEND')=='software':
        return render_software(parts,out,colors,states,frames,size,gif_size,status,bed)
    os.makedirs(out, exist_ok=True); colors = colors or {}
    data = {'bed': bed, 'parts': [mesh_json(m, colors.get(n, PALETTE[i % len(PALETTE)]), n) for i, (n, m) in enumerate(parts.items())], 'states': states or {},
            'firstState': next(iter(states)) if states else '', 'status': status or ''}
    json.dump(data, open(os.path.join(out, 'data.json'), 'w'))
    for suffix, (w, h) in (('', size), ('_gif', gif_size)):
        open(os.path.join(out, f'index{suffix}.html'), 'w', encoding='utf-8').write(offline_html(data, w, h))
    from playwright.sync_api import sync_playwright
    from PIL import Image
    import io
    pngs = {}
    with sync_playwright() as p:
        kw = dict(executable_path=CHROME) if CHROME else {}
        b = p.chromium.launch(args=['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--allow-file-access-from-files'], **kw)
        pg = b.new_page(viewport={'width': size[0], 'height': size[1]}); pg.goto((Path(out) / 'index.html').resolve().as_uri()); pg.wait_for_function('window.READY===true', timeout=30000)
        state_names = list(states) if states else ['']
        for st in state_names:
            pg.evaluate(f'window.setState({json.dumps(st)})')
            for v in ('iso', 'top', 'side', 'bottom', 'front'):
                pg.evaluate(f'window.setView({json.dumps(v)},0)'); fn = f'view_{v}' + (f'_{st}' if st else '') + '.png'
                pg.screenshot(path=os.path.join(out, fn)); pngs[fn] = fn
        pg.close()
        pg = b.new_page(viewport={'width': gif_size[0], 'height': gif_size[1]}); pg.goto((Path(out) / 'index_gif.html').resolve().as_uri()); pg.wait_for_function('window.READY===true', timeout=30000)
        imgs = []
        per = max(1, frames // len(state_names))
        for st in state_names:
            pg.evaluate(f'window.setState({json.dumps(st)})')
            for k in range(per):
                pg.evaluate(f'window.setView("iso",{360.0 * k / per})'); imgs.append(Image.open(io.BytesIO(pg.screenshot())).convert('RGB').quantize(colors=128, method=Image.Quantize.MEDIANCUT))
        b.close()
    imgs[0].save(os.path.join(out, 'turntable.gif'), save_all=True, append_images=imgs[1:], duration=int(4000 / max(1, len(imgs))), loop=0, optimize=True)
    return pngs

if __name__ == '__main__':
    if '--check' in sys.argv: sys.exit(0 if check() else 1)
    ap = argparse.ArgumentParser(); ap.add_argument('files', nargs='+'); ap.add_argument('--out', required=True); ap.add_argument('--colors', default='')
    ap.add_argument('--states'); ap.add_argument('--frames', type=int, default=36); ap.add_argument('--status', default=''); ap.add_argument('--bed', type=int, default=256)
    a = ap.parse_args(); parts = load(a.files)
    colors = dict(kv.split('=') for kv in a.colors.split(',') if '=' in kv)
    states = json.load(open(a.states)) if a.states else None
    size = [sum(m.bounds[1][i] for m in parts.values()) for i in range(3)]
    allb = np.array([m.bounds for m in parts.values()]); mn, mx = allb[:, 0].min(0), allb[:, 1].max(0)
    status = a.status or f'완료 — 모델 크기 {mx[0]-mn[0]:.1f} × {mx[1]-mn[1]:.1f} × {mx[2]-mn[2]:.1f} mm · 파트 {len(parts)}개: ' + ', '.join(parts)
    print(render(parts, a.out, colors, states, a.frames, status=status, bed=a.bed)); print('gif:', os.path.join(a.out, 'turntable.gif'))
