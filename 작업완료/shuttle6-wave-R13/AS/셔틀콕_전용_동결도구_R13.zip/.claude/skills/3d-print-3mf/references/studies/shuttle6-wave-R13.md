# Shuttle6 R13: flat guide and six sliding detent rows

User correction: prior mechanisms left thin weak regions; preserve full 2.6mm trough wall. The zero-clearance proposal is an idea, not a requirement: user requested external project review before deciding. Six rows run along length, on both sides, per reference sketch.

## Primary sources reviewed 2026-10-22
- b3dkit slide_box source: https://github.com/x0pherl/b3dkit/blob/main/src/b3dkit/slide_box.py ; separates tolerance from divot geometry; explicitly avoids needle-thin slivers where divots graze taper. Numerical tolerances in this source describe its own geometry and are not directly transferable to a 243mm case.
- b3dkit guide: https://b3dkit.readthedocs.io/en/latest/slide_box/ ; 2–3mm general walls, test fit and controlled printing speed.
- Makers Making Change OpenAT Snap Fits, deployed in Chatterbox: https://makersmakingchange.github.io/OpenAT_Design_Guide/Design_Elements_For_3D_Printed_Parts/Snap_Fits.html ; smooth transitions, two-sided ramps for release, orientation and fit testing. Its 0.4mm empirical clearance is specific to its fin snap and is not copied.
- Fictiv: https://www.fictiv.com/articles/how-to-design-snap-fit-components ; stress concentration, creep relaxation and fatigue; avoid prolonged assembled stress. No generic PLA strain is treated as a repeated-life guarantee.
- Formlabs: https://formlabs.com/global/blog/designing-3d-printed-snap-fit-enclosures/ ; annular/shell compliance is distinct from cantilever snaps. Different printing processes require independent fit tests.

Printables examples 180053 and 971486 were found in indexed descriptions but full pages failed to load. No claim of STL inspection or successful durability testing is made.

## Application and limits
Use a single filled lower bore flat, nominal guide gap0.3mm. Six broad paired solid nubs at36mm pitch; rounded R3 cam and R3.2 mating pockets give0.2mm local relaxed gap. Peak radial overclosure0.15mm is deliberately distinct from sliding gap. The open trough wall provides compliance without slots or a thin neck. Full 2.6mm base wall retained. Aligned six rows flex together, so effort may be greatest near closed and decrease as extracted. Not claimed uniform click force. Force, sound, wear and cycle life require physical trials; a small coupon only checks local fit, not full six-row force.

Preserve outer two-piece adhesive alignment joint and cap connection; they serve different functions. Minimum male collar radial wall beneath shallow new recess>=1.8mm. The upper glue socket temporarily relieves the floor rail; the original3.5mm socket taper is followed by4mm gentle guide lead-in. This is not a full-length unbroken flat.

## Incremental mesh repair lesson
Filling an old deeper spherical recess with a coincident sphere-only patch produced a watertight single solid, but numerical duplicate faces caused sliced inner loops to collapse at three nearby levels. QC falsely saw full-core overhangs around the patch. Restore an entire bore band with positive overlap into the parent wall, recut the continuous bore, then add rail and new pockets. Measure section area and inner-loop count before full QC. For this repair,13 sampled slices retained one interior and approximately1411–1413mm² wall area. This does not replace complete QC.

The final low cams are5mm below the open rim. A previous temporary layout centered only1.5mm below the rim left very thin upper tips; moving down fully supports the nub roots without cutting the2.6mm parent wall.

Additional source inspected: https://github.com/x0pherl/b3dkit/blob/main/src/b3dkit/click_fit.py uses a broad tapered divot with a chamfered crown and an extended base; the author's wear advantage claim is not a fatigue test and is not represented as proof for our low spherical-segment cams.
