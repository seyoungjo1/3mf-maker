# R14: additive cradle, full circular chamber

User correction: R13 flattened and filled the inner bottom. This was incorrect. Preserve the full open circular64mm chamber; add material only OUTSIDE the original2.6mm radial wall. The reference sketch shows an external cradle. Matching external-shell channel and six paired detents belong INSIDE that rail, not near the open upper rims. User also wants to avoid support contact on the long inner tray/rail surfaces.

## Geometry
The external cradle has a flat bed base and flared sides tangent to the34.6mm outer circle. The original32mm inner semicircle is subtracted after the union so no cradle material fills it. BaseY=-35.2; original inner floorY=-32, total underside3.2mm. Side slope dx/dy=.4, or0.08mm per0.2mm layer. The bore is the circular reference plus a0.3mm offset of the cradle. External shell gets a2.6mm rail-wall reinforcement; nominal outer bounding width/height remain78.2mm, although the bottom contour changes.

Six paired low solid cam patches have5mm smooth lower lead-in,2mm upper return, axial6mm width, normal protrusion0.4mm. Nominal rail gap0.3mm therefore needs0.1mm crossing deformation. Groove surface offset0.2mm is distinct. A cosine height field keeps the increasing-side printed dx/dy below0.55 (0.11mm/layer); no thin cantilever leaf is created. A preliminary compact ellipsoid on the steeper0.55 cradle generated small rail support contacts and was replaced.

The broad cradle needs a clear passage across the two-body glue joint. Bottom sector of sleeve is opened atY=-17; engagement22mm replaces14mm to restore nominal wrapped bond area. This is not a physical bond-strength guarantee. Female bottom wall continuously guides the rail. Upper taper length5mm keeps the radial step below0.115mm/layer. The old45-degree key is retained.

Force/fatigue assumptions: the cams are solid and the outer shell/rail must deform slightly; straight-cantilever formulas cannot rate this mechanism. Cap protected beam remains independently checked by the existing beam approximation. Neither modeled compressed cam poses nor nominal bonded area proves real force, wear or lifetime.

Reference sketch has no metric scale; actual dimensions come from CAD and user-established64mm chamber. Full body, cap socket, coupon and tip are rebuilt together. Physical feather-brand six-stack capacity remains untested225mm assumption.
